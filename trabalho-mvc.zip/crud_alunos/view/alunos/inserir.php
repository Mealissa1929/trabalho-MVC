<?php

require_once(__DIR__ . "/../../model/Aluno.php");
require_once(__DIR__ . "/../../model/Curso.php");
require_once(__DIR__ . "/../../controller/AlunoController.php");

$msgErro = "";
$aluno = NULL;

if(isset($_POST['nome'])){
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $estrang = trim($_POST['estrangeiro']) ? trim($_POST['estrangeiro']) : NULL;
    $idCurso = is_numeric($_POST['curso']) ? $_POST['curso'] : NULL;

    $curso = new Curso();
    $curso->setId($idCurso);
    $aluno = new Aluno($nome, $idade, $estrang, $curso);
    $aluno->setId(0);

    $alunoCont = new AlunoController();
    $erros = $alunoCont->inserir($aluno);

    if(empty($erros))
        header("location: inserir.php");
    else
        $msgErro = implode("<br>", $erros);
    
}

require_once(__DIR__ . "/form.php");
?>